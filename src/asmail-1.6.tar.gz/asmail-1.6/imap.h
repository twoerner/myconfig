/*
 * asmail is the AfterStep mailbox monitor
 * Copyright (c) 2002 Albert Dorofeev <albert@tigr.net>
 * For the updates see http://www.tigr.net/
 *
 * This software is distributed under GPL. For details see LICENSE file.
 */

#ifndef _IMAP_H_
#define _IMAP_H_

#include "globals.h"

#define PORT_IMAP 143
#define IMAP_MAILBOX_DEFAULT "INBOX"
void imap_handle( struct mbox_struct * mb );

#endif

