#ifndef _MAILDIR_H_
#define _MAILDIR_H_

#include "globals.h"

void maildir_handle( struct mbox_struct * mb );

#endif

