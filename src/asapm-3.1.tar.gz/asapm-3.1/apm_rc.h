#ifndef _apm_rc_h_
#define _apm_rc_h_

/*
 * Read the given configuration file.
 * Returns zero if succesful.
 */
int ReadConfiguration(char * file_name);

#endif

